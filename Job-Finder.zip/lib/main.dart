import 'package:flutter/material.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
        title: "",
        home: new Scaffold(
          appBar: new AppBar(
            title: new Text("JobFinder"),
          ),
          body: new ListView(
            children: <Widget>[
              new Image.asset('assets/image/logo.jpg'),
              Center(
                  //margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                  child: Column(children: <Widget>[
                Text(
                  "Categories:",
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                ),
                RaisedButton(
                  //padding: EdgeInsets.only(top: 20.0),
                  child: Text(
                    'PART TIME',
                    style: TextStyle(fontSize: 25),
                  ),
                  onPressed: () {},
                  color: Colors.pink[80],
                  shape: RoundedRectangleBorder(
                    borderRadius: const BorderRadius.all(
                      Radius.circular(20.0),
                    ),
                  ),
                ),
                RaisedButton(
                  child: Text(
                    'FULL TIME',
                    style: TextStyle(fontSize: 25),
                  ),
                  onPressed: () {},
                  color: Colors.pink[80],
                  shape: RoundedRectangleBorder(
                    borderRadius: const BorderRadius.all(
                      Radius.circular(20.0),
                    ),
                  ),
                ),
              ])),
            ],
          ),
        ));
  }
}
  